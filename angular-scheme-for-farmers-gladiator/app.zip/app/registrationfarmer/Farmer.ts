
export class Farmer {
  name: string=""
  email: string=""
  mobileNo:string=""
  address:string=""
  city:string=""
  state:string=""
  pincode:string=""
  accountNo:string=""
  ifscCode:string=""
  aadharNo:string=""
  area:string=""
  status:number=2
}
