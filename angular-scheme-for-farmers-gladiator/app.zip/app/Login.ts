export class Login{
    id:string;
    password:string;
    type:string;
}