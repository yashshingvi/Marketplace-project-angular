export class HandleRequest {
    id: number;
    status: any;
    type: any;
    bidder: any;
    sellRequest: any;
    farmer: any;
  }
  